<?php

use Illuminate\Support\Facades\Route;
use Inudev\BannerPopup\Http\Controllers\BannerPopupController;

Route::prefix(config('banner-popup.route_prefix', 'banner-popup'))
    ->middleware(config('banner-popup.route_middleware', ['web']))
    ->name('banner-popup.')
    ->group(function () {

        // Returns JSON payload of all active banners for the current page.
        // The JS frontend hits this endpoint on page load.
        // Query param: ?page=route.name
        Route::get('/active', [BannerPopupController::class, 'active'])
            ->name('active');

        // Called by the JS after a banner is shown, so the server can
        // record the impression (currently just returns 204 — extensible).
        Route::post('/{banner}/seen', [BannerPopupController::class, 'seen'])
            ->name('seen');

    });
