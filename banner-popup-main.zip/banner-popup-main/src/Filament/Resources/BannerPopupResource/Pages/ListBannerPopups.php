<?php

namespace Inudev\BannerPopup\Filament\Resources\BannerPopupResource\Pages;

use Filament\Actions;
use Filament\Resources\Pages\ListRecords;
use Inudev\BannerPopup\Filament\Resources\BannerPopupResource;

class ListBannerPopups extends ListRecords
{
    protected static string $resource = BannerPopupResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
