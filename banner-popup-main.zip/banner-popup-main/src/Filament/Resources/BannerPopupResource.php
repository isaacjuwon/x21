<?php

namespace Inudev\BannerPopup\Filament\Resources;

use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Route;
use Inudev\BannerPopup\Filament\Resources\BannerPopupResource\Pages;
use Inudev\BannerPopup\Models\BannerPopup;

class BannerPopupResource extends Resource
{
    protected static ?string $model = BannerPopup::class;

    protected static ?string $navigationIcon = 'heroicon-o-photo';

    public static function getModelLabel(): string
    {
        return __('banner-popup::ui.model_label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('banner-popup::ui.model_label_plural');
    }

    public static function getNavigationGroup(): ?string
    {
        return __('banner-popup::ui.nav_group');
    }

    public static function getNavigationSort(): ?int
    {
        return 90;
    }

    // -------------------------------------------------------------------------
    // Form
    // -------------------------------------------------------------------------

    public static function form(Form $form): Form
    {
        return $form->schema([

            // ── Left column (span 2) ──────────────────────────────────────────
            Forms\Components\Group::make()
                ->schema([

                    // Images section
                    Forms\Components\Section::make(__('banner-popup::ui.sections.images'))
                        ->description(__('banner-popup::ui.descriptions.images'))
                        ->icon('heroicon-o-photo')
                        ->columns(3)
                        ->schema([
                            Forms\Components\SpatieMediaLibraryFileUpload::make('banner_desktop')
                                ->label(__('banner-popup::ui.fields.banner_desktop'))
                                ->collection('banner_desktop')
                                ->image()
                                ->imageEditor()
                                ->acceptedFileTypes(config('banner-popup.accepted_mime_types'))
                                ->helperText(__('banner-popup::ui.helpers.banner_desktop')),

                            Forms\Components\SpatieMediaLibraryFileUpload::make('banner_tablet')
                                ->label(__('banner-popup::ui.fields.banner_tablet'))
                                ->collection('banner_tablet')
                                ->image()
                                ->imageEditor()
                                ->acceptedFileTypes(config('banner-popup.accepted_mime_types'))
                                ->helperText(__('banner-popup::ui.helpers.banner_tablet')),

                            Forms\Components\SpatieMediaLibraryFileUpload::make('banner_mobile')
                                ->label(__('banner-popup::ui.fields.banner_mobile'))
                                ->collection('banner_mobile')
                                ->image()
                                ->imageEditor()
                                ->acceptedFileTypes(config('banner-popup.accepted_mime_types'))
                                ->helperText(__('banner-popup::ui.helpers.banner_mobile')),
                        ]),

                    // Trigger / activation section
                    Forms\Components\Section::make(__('banner-popup::ui.sections.activation'))
                        ->description(__('banner-popup::ui.descriptions.activation'))
                        ->icon('heroicon-o-bolt')
                        ->schema([
                            Forms\Components\TextInput::make('name')
                                ->label(__('banner-popup::ui.fields.name'))
                                ->required()
                                ->maxLength(150),

                            Forms\Components\Select::make('trigger')
                                ->label(__('banner-popup::ui.fields.trigger'))
                                ->options([
                                    'page_load'   => __('banner-popup::ui.trigger_options.page_load'),
                                    'delay'       => __('banner-popup::ui.trigger_options.delay'),
                                    'exit_intent' => __('banner-popup::ui.trigger_options.exit_intent'),
                                ])
                                ->default('page_load')
                                ->live()
                                ->required(),

                            Forms\Components\TextInput::make('trigger_delay')
                                ->label(__('banner-popup::ui.fields.trigger_delay'))
                                ->numeric()
                                ->minValue(1)
                                ->suffix(__('banner-popup::ui.suffix.seconds'))
                                ->visible(fn (Forms\Get $get) => $get('trigger') === 'delay'),
                        ]),

                    // Display rules section
                    Forms\Components\Section::make(__('banner-popup::ui.sections.display_rules'))
                        ->description(__('banner-popup::ui.descriptions.display_rules'))
                        ->icon('heroicon-o-adjustments-horizontal')
                        ->schema([
                            Forms\Components\TextInput::make('link_url')
                                ->label(__('banner-popup::ui.fields.link_url'))
                                ->url()
                                ->nullable(),

                            Forms\Components\Select::make('link_target')
                                ->label(__('banner-popup::ui.fields.link_target'))
                                ->options([
                                    '_self'  => __('banner-popup::ui.link_target_options._self'),
                                    '_blank' => __('banner-popup::ui.link_target_options._blank'),
                                ])
                                ->default('_self'),

                            Forms\Components\Select::make('show_frequency')
                                ->label(__('banner-popup::ui.fields.show_frequency'))
                                ->options([
                                    0  => __('banner-popup::ui.frequency_options.always'),
                                    1  => __('banner-popup::ui.frequency_options.1'),
                                    3  => __('banner-popup::ui.frequency_options.3'),
                                    7  => __('banner-popup::ui.frequency_options.7'),
                                    30 => __('banner-popup::ui.frequency_options.30'),
                                    -1 => __('banner-popup::ui.frequency_options.once'),
                                ])
                                ->default(0),

                            Forms\Components\Select::make('target_pages')
                                ->label(__('banner-popup::ui.fields.target_pages'))
                                ->placeholder(__('banner-popup::ui.placeholders.target_pages'))
                                ->helperText(__('banner-popup::ui.helpers.target_pages'))
                                ->multiple()
                                ->searchable()
                                ->options(fn () => static::getPublicRouteOptions())
                                ->nullable(),
                        ]),
                ])
                ->columnSpan(['lg' => 2]),

            // ── Right column (span 1) ─────────────────────────────────────────
            Forms\Components\Group::make()
                ->schema([
                    Forms\Components\Section::make(__('banner-popup::ui.sections.publication'))
                        ->description(__('banner-popup::ui.descriptions.publication'))
                        ->icon('heroicon-o-eye')
                        ->columns(2)
                        ->schema([
                            Forms\Components\Toggle::make('is_active')
                                ->label(__('banner-popup::ui.fields.is_active'))
                                ->helperText(__('banner-popup::ui.helpers.is_active'))
                                ->inline(false)
                                ->columnSpan(2),

                            Forms\Components\DateTimePicker::make('starts_at')
                                ->label(__('banner-popup::ui.fields.starts_at'))
                                ->nullable()
                                ->native(false),

                            Forms\Components\DateTimePicker::make('ends_at')
                                ->label(__('banner-popup::ui.fields.ends_at'))
                                ->nullable()
                                ->native(false)
                                ->after('starts_at'),
                        ]),
                ])
                ->columnSpan(['lg' => 1]),

        ])->columns(3);
    }

    // -------------------------------------------------------------------------
    // Table
    // -------------------------------------------------------------------------

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')
                    ->label(__('banner-popup::ui.fields.name'))
                    ->searchable()
                    ->sortable(),

                Tables\Columns\ToggleColumn::make('is_active')
                    ->label(__('banner-popup::ui.fields.is_active')),

                Tables\Columns\TextColumn::make('trigger')
                    ->label(__('banner-popup::ui.fields.trigger'))
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'page_load'   => 'info',
                        'delay'       => 'warning',
                        'exit_intent' => 'danger',
                        default       => 'gray',
                    })
                    ->formatStateUsing(fn (string $state): string => match ($state) {
                        'page_load'   => __('banner-popup::ui.trigger_options.page_load'),
                        'delay'       => __('banner-popup::ui.trigger_options.delay'),
                        'exit_intent' => __('banner-popup::ui.trigger_options.exit_intent'),
                        default       => $state,
                    }),

                Tables\Columns\TextColumn::make('starts_at')
                    ->label(__('banner-popup::ui.fields.starts_at'))
                    ->dateTime('d/m/Y H:i')
                    ->placeholder('—')
                    ->sortable(),

                Tables\Columns\TextColumn::make('ends_at')
                    ->label(__('banner-popup::ui.fields.ends_at'))
                    ->dateTime('d/m/Y H:i')
                    ->placeholder('—')
                    ->sortable(),

                Tables\Columns\IconColumn::make('currently_active')
                    ->label(__('banner-popup::ui.columns.currently_active'))
                    ->state(fn (BannerPopup $record): bool => $record->isCurrentlyActive())
                    ->boolean(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->defaultSort('created_at', 'desc');
    }

    // -------------------------------------------------------------------------
    // Pages
    // -------------------------------------------------------------------------

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListBannerPopups::route('/'),
            'create' => Pages\CreateBannerPopup::route('/create'),
            'edit'   => Pages\EditBannerPopup::route('/{record}/edit'),
        ];
    }

    public static function getRecordTitle(Model|null $record): ?string
    {
        return $record?->name;
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Build the options array for the target_pages selector,
     * filtering out internal/system routes using the config exclusion list.
     */
    protected static function getPublicRouteOptions(): array
    {
        $excluded = config('banner-popup.excluded_route_prefixes', []);

        return collect(Route::getRoutes())
            ->filter(function ($route) use ($excluded): bool {
                $name = $route->getName();

                if (! $name) {
                    return false;
                }

                foreach ($excluded as $prefix) {
                    if (str_starts_with($name, $prefix)) {
                        return false;
                    }
                }

                return in_array('GET', $route->methods(), true);
            })
            ->mapWithKeys(fn ($route) => [
                $route->getName() => $route->getName() . '  (' . $route->uri() . ')',
            ])
            ->sort()
            ->toArray();
    }
}
